import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

/*
  IMPORTANT:
  Replace this config with the SAME Firebase web app configuration
  already used by PleyZ. Do not put Admin SDK credentials here.
*/
const firebaseConfig = window.PLEYZ_FIREBASE_CONFIG || {
  apiKey: "REPLACE_ME",
  authDomain: "REPLACE_ME.firebaseapp.com",
  projectId: "REPLACE_ME",
  storageBucket: "REPLACE_ME",
  messagingSenderId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

const API_BASE_URL = window.PLEYZ_ADMIN_API_BASE_URL || "https://YOUR-BACKEND.example.com";
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const $ = s => document.querySelector(s);
const authView=$("#authView"), appView=$("#appView"), loginForm=$("#loginForm");
let currentUser=null;

function setError(message){$("#loginError").textContent=message||""}
function setStatus(message){$("#status").textContent=message||""}

async function api(path, options={}){
  if(!currentUser) throw new Error("Not signed in");
  const token=await currentUser.getIdToken();
  const headers={"Authorization":`Bearer ${token}`,"Content-Type":"application/json",...(options.headers||{})};
  const r=await fetch(`${API_BASE_URL}${path}`,{...options,headers});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.detail||"Request failed");
  return data;
}

loginForm.addEventListener("submit",async e=>{
  e.preventDefault(); setError("");
  try{await signInWithEmailAndPassword(auth,$("#email").value.trim(),$("#password").value)}
  catch(err){setError("Sign-in failed. Check the account details.");}
});

$("#logoutBtn").addEventListener("click",()=>signOut(auth));
$("#refreshBtn").addEventListener("click",loadDashboard);

onAuthStateChanged(auth,async user=>{
  currentUser=user;
  if(!user){authView.classList.remove("hidden");appView.classList.add("hidden");return}
  try{
    const token=await user.getIdTokenResult(true);
    if(token.claims.admin!==true) throw new Error("Not authorized");
    $("#userLabel").textContent=user.email||"Authorized admin";
    authView.classList.add("hidden");appView.classList.remove("hidden");
    await loadDashboard();
  }catch{
    await signOut(auth);setError("This Firebase account is not authorized for the PleyZ newsroom.");
  }
});

async function loadDashboard(){
  try{
    setStatus("Loading…");
    const data=await api("/api/v1/admin/dashboard");
    $("#draftCount").textContent=data.needsReview||0;
    $("#publishedCount").textContent=data.published||0;
    $("#sourceCount").textContent=data.sources||0;
    renderArticles(data.articles||[]);
    setStatus("");
  }catch(e){setStatus(e.message)}
}

function renderArticles(items){
  $("#articleList").innerHTML=items.length?items.map(a=>`
    <article class="article-item" data-id="${escapeHtml(a.id)}">
      <div class="article-top"><div><span class="badge">${escapeHtml(a.category||"Uncategorized")}</span>
      <h3>${escapeHtml(a.title)}</h3></div><span class="badge">${escapeHtml(a.status||"NEEDS_REVIEW")}</span></div>
      <p>${escapeHtml(a.excerpt||"")}</p>
      <div class="sources">${(a.sources||[]).map(s=>`<a target="_blank" rel="noopener" href="${escapeHtml(s.url)}">${escapeHtml(s.title||s.url)}</a>`).join("")}</div>
      <div class="actions"><button data-action="open">Open draft</button><button class="reject" data-action="reject">Reject</button><button class="approve" data-action="approve">Approve & Publish</button></div>
    </article>`).join(""):"<p class='status'>Nothing is waiting for review.</p>";
}

$("#articleList").addEventListener("click",async e=>{
  const button=e.target.closest("button"); if(!button)return;
  const card=button.closest(".article-item"), id=card?.dataset.id;
  if(!id)return;
  try{
    if(button.dataset.action==="approve"){
      if(!confirm("Approve and publish this article?"))return;
      await api(`/api/v1/admin/articles/${encodeURIComponent(id)}/approve`,{method:"POST"});
      await loadDashboard();
    }else if(button.dataset.action==="reject"){
      await api(`/api/v1/admin/articles/${encodeURIComponent(id)}/reject`,{method:"POST",body:JSON.stringify({reason:"Rejected in newsroom"})});
      await loadDashboard();
    }else{
      const data=await api(`/api/v1/admin/articles/${encodeURIComponent(id)}`);
      alert(`Draft preview:\\n\\n${data.title}\\n\\n${data.body}`);
    }
  }catch(err){setStatus(err.message)}
});

$("#importBtn").addEventListener("click",()=>$("#jsonFile").click());
$("#jsonFile").addEventListener("change",async e=>{
  const file=e.target.files[0]; if(!file)return;
  try{
    const parsed=JSON.parse(await file.text());
    await api("/api/v1/admin/articles/import",{method:"POST",body:JSON.stringify(parsed)});
    setStatus("JSON imported as a draft. It still requires human approval.");
    await loadDashboard();
  }catch(err){setStatus(`Import failed: ${err.message}`)}
  e.target.value="";
});

function escapeHtml(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
