"""
PleyZ News backend starter.

This module is intentionally backend-only. It expects:
- Firebase Admin SDK for ID-token verification
- a database layer for articles/sources
- a server-side GitHub token for publishing
- Gemini integration in a separate service

Do NOT put any of these secrets in GitHub Pages/frontend JS.
"""

import os
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel, Field, HttpUrl

router = APIRouter(prefix="/api/v1")

ADMIN_FIREBASE_UID = os.environ.get("PLEYZ_ADMIN_FIREBASE_UID", "")

# Replace these placeholders with your existing Firebase Admin initialization.
# The Admin SDK verifies the token cryptographically on the server.
try:
    import firebase_admin
    from firebase_admin import auth as firebase_auth
    if not firebase_admin._apps:
        firebase_admin.initialize_app()
except Exception:
    firebase_auth = None


class Source(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    url: HttpUrl
    type: str = Field(default="source", max_length=50)


class ArticleImport(BaseModel):
    title: str = Field(min_length=5, max_length=180)
    slug: str = Field(min_length=3, max_length=180, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    category: str = Field(min_length=2, max_length=60)
    excerpt: str = Field(min_length=1, max_length=400)
    body: str = Field(min_length=1, max_length=100000)
    sources: list[Source] = Field(default_factory=list)
    image: Optional[HttpUrl] = None


async def require_admin(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    if firebase_auth is None:
        raise HTTPException(status_code=503, detail="Firebase Admin is not configured")

    token = authorization[7:].strip()
    try:
        decoded = firebase_auth.verify_id_token(token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid authentication token")

    # Prefer a custom admin claim. Keep the UID allowlist as an additional
    # defense while there is only one administrator.
    is_admin_claim = decoded.get("admin") is True
    is_admin_uid = bool(ADMIN_FIREBASE_UID) and decoded.get("uid") == ADMIN_FIREBASE_UID

    if not (is_admin_claim or is_admin_uid):
        raise HTTPException(status_code=403, detail="Admin access denied")

    return decoded


@router.get("/news/published")
async def published_news():
    # TODO: Replace with a PostgreSQL query:
    # SELECT ... FROM published_articles ORDER BY published_at DESC
    return {"articles": []}


@router.get("/news/article/{slug}")
async def published_article(slug: str):
    # TODO: Query only published articles by permanent slug.
    raise HTTPException(status_code=404, detail="Article not found")


@router.get("/admin/dashboard")
async def admin_dashboard(_: Dict[str, Any] = Depends(require_admin)):
    # TODO: Replace with database counts and NEEDS_REVIEW articles.
    return {"needsReview": 0, "published": 0, "sources": 0, "articles": []}


@router.get("/admin/articles/{article_id}")
async def get_draft(article_id: str, _: Dict[str, Any] = Depends(require_admin)):
    # TODO: Fetch draft by internal article ID.
    raise HTTPException(status_code=404, detail="Draft not found")


@router.post("/admin/articles/import")
async def import_article(payload: ArticleImport, _: Dict[str, Any] = Depends(require_admin)):
    # IMPORTANT: import creates a draft. It does not publish.
    # TODO: validate, sanitize, and INSERT status='NEEDS_REVIEW'.
    return {"ok": True, "status": "NEEDS_REVIEW", "slug": payload.slug}


@router.post("/admin/articles/{article_id}/approve")
async def approve_article(article_id: str, _: Dict[str, Any] = Depends(require_admin)):
    # IMPORTANT:
    # 1. Load article and ensure status == NEEDS_REVIEW.
    # 2. Validate required source evidence.
    # 3. Generate final static article.
    # 4. Commit it to GitHub using a server-side credential.
    # 5. Only after a successful commit set status=PUBLISHED.
    # TODO: implement transaction + GitHub publishing.
    raise HTTPException(status_code=501, detail="Publishing service not configured yet")


@router.post("/admin/articles/{article_id}/reject")
async def reject_article(article_id: str, _: Dict[str, Any] = Depends(require_admin)):
    # TODO: update status='REJECTED' and store the review timestamp/reason.
    return {"ok": True, "status": "REJECTED"}
