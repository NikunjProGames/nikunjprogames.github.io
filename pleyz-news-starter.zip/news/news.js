const API_BASE_URL = window.PLEYZ_NEWS_API_BASE_URL || "";
const fallbackArticles = [
  {
    id:"demo-1", category:"browser", title:"Welcome to PleyZ News",
    excerpt:"A source-driven gaming news hub for browser games, updates and stories worth knowing about.",
    publishedAt:"2026-09-22T00:00:00Z",
    readTime:3, image:"",
    slug:"welcome-to-pleyz-news",
    games:[]
  },
  {
    id:"demo-2", category:"updates", title:"How PleyZ News will verify stories",
    excerpt:"Every AI-assisted story goes through source checks and human review before publication.",
    publishedAt:"2026-09-22T00:00:00Z",
    readTime:4, image:"",
    slug:"how-pleyz-news-verifies-stories",
    games:[]
  }
];

let articles = [];
let activeCategory = "all";

async function loadArticles(){
  try{
    if(!API_BASE_URL) throw new Error("API not configured");
    const r = await fetch(`${API_BASE_URL}/api/v1/news/published`, {headers:{Accept:"application/json"}});
    if(!r.ok) throw new Error("News API failed");
    const data = await r.json();
    articles = Array.isArray(data.articles) ? data.articles : [];
  }catch{
    articles = fallbackArticles;
  }
  render();
}

function formatDate(value){
  return new Intl.DateTimeFormat(undefined,{dateStyle:"medium"}).format(new Date(value));
}

function imageStyle(image){
  return image ? `style="background-image:url('${escapeHtml(image)}')"` : "";
}

function escapeHtml(value=""){
  return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function render(){
  const filtered = activeCategory==="all" ? articles : articles.filter(a=>a.category===activeCategory);
  document.querySelector("#articleCount").textContent = `${filtered.length} stor${filtered.length===1?"y":"ies"}`;
  const featured = filtered[0];
  document.querySelector("#featured").innerHTML = featured ? `
    <a class="feature-card" href="./article.html?slug=${encodeURIComponent(featured.slug)}">
      <div class="feature-image" ${imageStyle(featured.image)}></div>
      <div class="feature-copy">
        <div class="meta">${escapeHtml(featured.category)} · ${formatDate(featured.publishedAt)} · ${featured.readTime||3} min read</div>
        <h2>${escapeHtml(featured.title)}</h2>
        <p>${escapeHtml(featured.excerpt||"")}</p>
      </div>
    </a>` : "";

  document.querySelector("#articleGrid").innerHTML = filtered.slice(1).map(a=>`
    <a class="article-card" href="./article.html?slug=${encodeURIComponent(a.slug)}">
      <div class="card-image" ${imageStyle(a.image)}></div>
      <div class="card-copy">
        <div class="meta">${escapeHtml(a.category)} · ${formatDate(a.publishedAt)}</div>
        <h3>${escapeHtml(a.title)}</h3>
        <p>${escapeHtml(a.excerpt||"")}</p>
        <div class="meta">${a.readTime||3} min read →</div>
      </div>
    </a>`).join("");

  document.querySelector("#emptyState").classList.toggle("hidden",filtered.length!==0);
}

document.querySelector("#categoryTabs").addEventListener("click",e=>{
  const button=e.target.closest("button"); if(!button)return;
  activeCategory=button.dataset.category;
  document.querySelectorAll("#categoryTabs button").forEach(b=>b.classList.toggle("selected",b===button));
  render();
});

loadArticles();
