# PleyZ News + Newsroom starter

This is the UI and backend contract for the PleyZ News system.

## What is included

- `/news/` public PleyZ News feed
- `/news/article.html` article renderer
- `/admin/` Firebase-authenticated newsroom UI
- `backend/news_api.py` FastAPI security/API skeleton
- `.env.example` for server-only secrets

## Important

This starter deliberately does NOT include:
- Firebase Admin private keys
- Gemini API keys
- GitHub tokens
- PostgreSQL passwords
- a fake client-side admin password
- automatic publishing

Those belong on the backend only.

## Architecture

GitHub Pages
-> Firebase client login
-> Firebase ID token
-> PleyZ backend
-> verifyIdToken()
-> admin claim / UID authorization
-> PostgreSQL
-> Gemini
-> human review
-> GitHub API
-> GitHub Pages

## Before deployment

1. Replace the placeholder Firebase web config in `admin/admin.js` with the same public web config already used by PleyZ.
2. Point `PLEYZ_ADMIN_API_BASE_URL` at your HTTPS backend.
3. Set an `admin: true` Firebase custom claim OR configure the single authorized Firebase UID on the backend.
4. Deploy the FastAPI router into the existing PleyZ backend rather than creating a second backend if your current backend can host it.
5. Add PostgreSQL tables for sources, source_items, articles, article_sources, review_events and published articles.
6. Add Gemini server-side using the Google GenAI SDK. Use structured output for predictable article JSON, then validate it in your backend.
7. Add GitHub publishing using a server-side fine-grained credential with only the required repository Contents write permission.
8. Only transition NEEDS_REVIEW -> PUBLISHED after the backend successfully validates and commits the article.
9. Add a scheduled source collector after the manual newsroom flow works.
10. Keep automatic publishing disabled initially.

## JSON import shape

```json
{
  "title": "10 Browser Games Worth Playing",
  "slug": "10-browser-games-worth-playing",
  "category": "browser",
  "excerpt": "A curated selection...",
  "body": "<p>...</p>",
  "sources": [
    {
      "title": "Source title",
      "url": "https://example.com/source",
      "type": "source"
    }
  ]
}
```

Import always creates a draft and requires approval.
